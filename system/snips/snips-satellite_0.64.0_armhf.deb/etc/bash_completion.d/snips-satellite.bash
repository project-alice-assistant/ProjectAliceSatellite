_snips-satellite() {
    local i cur prev opts cmds
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}
    do
        case "${i}" in
            snips-satellite)
                cmd="snips-satellite"
                ;;
            
            *)
                ;;
        esac
    done

    case "${cmd}" in
        snips-satellite)
            opts=" -v -h -V -f -o -t -c -b -a -u  --no-mike --disable-playback --disable-capture --no_vad_inhibitor --vad_messages --verbose --color --no-color --no-exit-on-all-panics --mqtt-tls-disable-root-store --help --version --hijack --frame --mike --output --portaudio-capture --portaudio-playback --alsa-capture --alsa-playback --sensitivity --hotword-id --model --config --bus --mqtt --mqtt-username --mqtt-password --mqtt-tls-hostname --mqtt-tls-cafile --mqtt-tls-capath --mqtt-tls-client-cert --mqtt-tls-client-key --bind --assistant --user-dir  "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --hijack)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --frame)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -f)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mike)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --output)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -o)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --portaudio-capture)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --portaudio-playback)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --alsa-capture)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --alsa-playback)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --sensitivity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -t)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --hotword-id)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --model)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --config)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --bus)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-username)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-password)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-hostname)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-cafile)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-capath)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-cert)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --mqtt-tls-client-key)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --bind)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -b)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --assistant)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -a)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --user-dir)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -u)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        
    esac
}

complete -F _snips-satellite -o bashdefault -o default snips-satellite
